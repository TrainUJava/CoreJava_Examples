package com.example;

public class Sum
{
	private double a;
	private double b;

	public Sum(double a, double b)
	{
		this.a=a;
		this.b=b;
	}

	public double getSum()
	{
		return (a+b);
	}
};
