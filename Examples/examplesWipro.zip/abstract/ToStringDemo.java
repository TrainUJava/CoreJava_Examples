class ToStringDemo
{
	public String toString()
	{
	return "This is Overriden toString()";
	}
	public static void main(String[] args) 
	{
	ToStringDemo ts = new ToStringDemo();


		System.out.println(ts);
	}
}
