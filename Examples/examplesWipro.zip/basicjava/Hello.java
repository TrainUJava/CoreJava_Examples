public class Hello {

	/**
	* My first Java program
	 */
public static void main( String[] args ){

		//prints the string �Hello world� on screen
		System.out.println("Hello world");
	 }
}