//subString Demo;
//JavaPoint Computers;
public class SubStrDemo {

    public static void main(String[] args) {

        String s1 = "Hyderabad";
        String s2 = s1.substring(3); 
        String s3 = s1.substring(5, 7); 

        System.out.println(s2);
        System.out.println(s3);
    }
}

