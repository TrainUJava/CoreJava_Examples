// Replace and CaseChange Demo;
//Javapoint Computers;
public class CaseDemo{

    public static void main(String[] args) {

        String s1 = "   Hyderabad   ";
        String s2 = s1.replace('a', 'z'); 
        System.out.println(s2);
System.out.println(s1.toLowerCase());
System.out.println(s1.toUpperCase());
        System.out.println(s1);
        System.out.println(s1.trim());

    }
}

