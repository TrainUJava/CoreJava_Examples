//IndexOf Demo;
//JavaPoint Computers;
public class IndexOfDemo{

    public static void main(String[] args) {

        String s1 = "Hyderabad";
        System.out.println
              (s1.indexOf('r'));
        System.out.println
              (s1.lastIndexOf('r'));
        System.out.println
              (s1.indexOf('a'));
        System.out.println
              (s1.lastIndexOf('a'));


    }
}

