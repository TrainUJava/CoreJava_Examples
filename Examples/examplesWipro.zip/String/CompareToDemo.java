//DemoFor CompareTo;
//JavaPoint Computers;
public class CompareToDemo {

    public static void main(String[] args) {

        String s1 = "Hyderabad";
        String s2 = "Madras";
        String s3 = "Nellore";
        String s4 = "ongole";
        String s5 = "Ongole";

        System.out.println
              (s4.compareTo(s5)); 
        System.out.println
              (s4.compareToIgnoreCase(s5)); 
    }
}

