
public class RegionMatchDemo {

    public static void main(String[] args) {

        String s1 = "Hyderabad";
        String s2 = "xxxerazzz"; 

        System.out.println
        (s1.regionMatches(3, s2, 3, 3)); 
    }
}

