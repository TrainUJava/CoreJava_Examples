class A 
{
	String s = "JavaPoint";
	public static void main(String[] args) 
	{
		
		System.out.println(s);
	}
}
